package com.mycompany.sistemadegestionyalertas;

import vista.VistaPrincipal;


public class SistemaDeGestionYAlertas {

    public static void main(String[] args) {
        VistaPrincipal vista = new VistaPrincipal();
        //Inicio la vista principal
        vista.vistaPrincipal();
    }
}
